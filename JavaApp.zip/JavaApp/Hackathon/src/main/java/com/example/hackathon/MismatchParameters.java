package com.example.hackathon;

public enum MismatchParameters {


    FIRSTNAME_PATTERN("First"),
    LASTNAME_PATTERN("Last"),
    USERNAME_PATTERN("Username"),
    PASSWORD_PATTERN("Password"),
    RETYPED_PASSWORD_PARAMETER("RetypedPassword");

    String mismatchPattern;

    MismatchParameters(String pattern){
        this.mismatchPattern = pattern;
    }


}
