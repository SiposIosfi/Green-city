package com.example.hackathon;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.regex.Pattern;

public class RegisterPageController {

    @FXML
    public AnchorPane registerBackground;

    @FXML
    public Label emptyFirstName;
    @FXML
    public TextField firstNameText;

    @FXML
    public Label emptyLastName;
    @FXML
    public TextField lastNameText;

    @FXML
    public Label emptyUsername;
    @FXML
    public TextField userNameText;

    @FXML
    public Label emptyPassword;
    @FXML
    public PasswordField passwordText;

    @FXML
    public Label emptyRetypedPassword;
    @FXML
    public PasswordField retypedPassword;



    public void initialize(){
        retypedPassword.setDisable(true);
        setPasswordLengthListener();
        setWarningsStyles();
       setFieldsInputType();
       setWarningsStyles();
    }


    public void registerUser(){
        displayEmptyWarningsLabels();
        shortPasswordWarning();
        if(passwordText.getText().length() < 8){
            shortPasswordWarning();
        }
        else if(!passwordText.getText().equals(emptyPassword.getText())){
            passwordDoNotMatch();
        }
        shortUsernameWarning();
    }



    private void setFieldsInputType(){
        final Pattern NAME_FILTER = Pattern.compile("[\\p{Upper}\\p{Lower}]*");
        final Pattern USERNAME_FILTER = Pattern.compile("[\\w_!@*\\-.]*");
        final Pattern PASSWORD_FILTER = Pattern.compile("\\S*");

        TextFormatter<String> firstNameFilterInput = new TextFormatter<>(change -> {
            if(NAME_FILTER.matcher(change.getControlNewText()).matches()){
                removeInputMismatchWarning(MismatchParameters.FIRSTNAME_PATTERN);
                return change;
            }
            displayInputMismatchWarning(MismatchParameters.FIRSTNAME_PATTERN);
            return null;
        });

        TextFormatter<String> secondNameFilterInput = new TextFormatter<>(change -> {
            if(NAME_FILTER.matcher(change.getControlNewText()).matches()){
                removeInputMismatchWarning(MismatchParameters.LASTNAME_PATTERN);
                return change;
            }
            displayInputMismatchWarning(MismatchParameters.LASTNAME_PATTERN);
            return null;
        });

        TextFormatter<String> usernameFilterInput = new TextFormatter<>(change -> {
            if(USERNAME_FILTER.matcher(change.getControlNewText()).matches()){
                removeInputMismatchWarning(MismatchParameters.USERNAME_PATTERN);
                return change;
            }
            displayInputMismatchWarning(MismatchParameters.USERNAME_PATTERN);
            return null;
        });

        TextFormatter<String> passwordFilterInput = new TextFormatter<>(change -> {
            if(PASSWORD_FILTER.matcher(change.getControlNewText()).matches()){
                removeInputMismatchWarning(MismatchParameters.PASSWORD_PATTERN);
                return change;
            }
            displayInputMismatchWarning(MismatchParameters.PASSWORD_PATTERN);
            return null;
        });

        TextFormatter<String> retypedPasswordFilterInput = new TextFormatter<>(change -> {
            if(PASSWORD_FILTER.matcher(change.getControlNewText()).matches()){
                removeInputMismatchWarning(MismatchParameters.RETYPED_PASSWORD_PARAMETER);
                return change;
            }
            displayInputMismatchWarning(MismatchParameters.RETYPED_PASSWORD_PARAMETER);
            return null;
        });

        firstNameText.setTextFormatter(firstNameFilterInput);
        lastNameText.setTextFormatter(secondNameFilterInput);
        userNameText.setTextFormatter(usernameFilterInput);
        passwordText.setTextFormatter(passwordFilterInput);
        retypedPassword.setTextFormatter(retypedPasswordFilterInput);
    }

    private void setPasswordLengthListener(){
        passwordText.textProperty().addListener((observableValue, oldVal, newVal) -> {
            if(newVal.length() >= 8){
                retypedPassword.setDisable(false);
            }
            else{
                retypedPassword.setDisable(true);
            }
        });
    }

    private void passwordDoNotMatch(){
        if(!passwordText.getText().equals(retypedPassword.getText())){
            emptyRetypedPassword.setText("Parolele nu coincid");
        }
        else{
            emptyRetypedPassword.setText("");
        }
    }

    private void shortUsernameWarning(){
        if(userNameText.getText().length() < 10){
            emptyUsername.setText("Minim 10 caractere");
        }
        else{
            emptyUsername.setText("");
        }
    }

    private void shortPasswordWarning(){
        if(passwordText.getText().length() < 8){
            emptyPassword.setText("Minim 8 caractere");
        }
        else{
            emptyPassword.setText("");
        }
    }

    private void removeInputMismatchWarning(MismatchParameters parameter){
        if (parameter.mismatchPattern.equals("First")){
            emptyFirstName.setText("");
        }
        if (parameter.mismatchPattern.equals("Last")){
            emptyLastName.setText("");
        }
        if (parameter.mismatchPattern.equals("Username")){
            emptyUsername.setText("");
        }
        if (parameter.mismatchPattern.equals("Password")){
            emptyPassword.setText("");
        }
        if (parameter.mismatchPattern.equals("RetypedPassword")){
            emptyRetypedPassword.setText("");
        }
    }

    private void displayInputMismatchWarning(MismatchParameters parameter){
        if (parameter.mismatchPattern.equals("First")){
            emptyFirstName.setText("Doar litere");
        }
        if (parameter.mismatchPattern.equals("Last")){
            emptyLastName.setText("Doar litere");
        }
        if (parameter.mismatchPattern.equals("Username")){
            emptyUsername.setText("Doar litere, cifre si _!@*-.");
        }
        if (parameter.mismatchPattern.equals("Password")){
            emptyPassword.setText("Fara spatii");
        }
        if (parameter.mismatchPattern.equals("RetypedPassword")){
            emptyRetypedPassword.setText("Fara spatii");
        }
    }

    private void displayEmptyWarningsLabels(){
        if(firstNameText.getText().length() > 0){
            emptyFirstName.setText("");
        }
        else{
            emptyFirstName.setText("Camp gol");
        }
        if(lastNameText.getText().length() > 0){
            emptyLastName.setText("");
        }
        else{
            emptyLastName.setText("Camp gol");
        }
        if(userNameText.getText().length() > 0){
            emptyUsername.setText("");
        }
        else{
            emptyUsername.setText("Camp gol");
        }
        if(passwordText.getText().length() > 0){
            emptyPassword.setText("");
        }
        else{
            emptyPassword.setText("Camp gol");
        }
        if(retypedPassword.getText().length() > 0){
            emptyRetypedPassword.setText("");
        }
        else{
            emptyRetypedPassword.setText("Camp gol");
        }
    }

    private void setWarningsStyles(){
        emptyFirstName.setFont(Font.font(10));
        emptyFirstName.setTextFill(Color.RED);
        emptyLastName.setFont(Font.font(10));
        emptyLastName.setTextFill(Color.RED);
        emptyUsername.setFont(Font.font(10));
        emptyUsername.setTextFill(Color.RED);
        emptyPassword.setFont(Font.font(10));
        emptyPassword.setTextFill(Color.RED);
        emptyRetypedPassword.setFont(Font.font(10));
        emptyRetypedPassword.setTextFill(Color.RED);
    }


}
