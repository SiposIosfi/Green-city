package TestsPackage;

public class Server {


}
