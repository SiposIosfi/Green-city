package TestsPackage;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;

public class ImageBytesTest {

    private Path localPath = FileSystems.getDefault().getPath(".\\src");
    private String pictureName = "TreePic.jpg";
    private String newImageName = "NewTreeImage.jpg";
    private String imageFormat = "";

    public void copyPictureBytes() throws IOException {
        File file = new File(localPath + File.separator + pictureName);

        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file), 1048576);
        ImageInputStream iis = ImageIO.createImageInputStream(bis);
        BufferedImage bim = ImageIO.read(iis);




        int imageWidth = bim.getWidth();
        int imageHeight = bim.getHeight();

        File newFile = new File(localPath + File.separator + newImageName);

        ImageIO.write(bim, "jpg", newFile);

        System.out.println(imageWidth);
        System.out.println(imageHeight);

    }

}
