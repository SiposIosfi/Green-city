package MainPackage;

import java.io.File;

public class Main {
    public static void main(String[] args) {


        PicturesDatabase database = new PicturesDatabase();
        database.openPicturesDatabase();

        File file = new File("./src/TicTacToe.png");

        database.insertPicture(file,"TicTacToe","Arad,Micalaca","2023-12-10","6:15",".png","Paul","citizen");

        database.closeConnection();



    }
}
