package MainPackage;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.sql.*;

public class PicturesDatabase {


    private Path localPath = FileSystems.getDefault().getPath("C:\\Users\\paulb\\Desktop\\MyGreenAppServerAndDatabase\\");
    private String databaseName = "PicturesDatabase.db";
    private String databaseLocation = "jdbc:sqlite:" + localPath + File.separator + databaseName;

    private Connection connection;


    private final String TABLE_NAME = "Pictures";
    private final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME;
    private final String TABLE_COLUMNS = " (Picture BLOB, PictureName TEXT, PictureLocation TEXT, PictureDate TEXT, PictureHour TEXT, PictureFormat TEXT, Username TEXT, UserType TEXT)";

    public final String QUERY_PICTURE_BY_USERNAME = "SELECT Picture FROM " + TABLE_NAME + " WHERE Username = ?";

    private final String QUERY_ALL_PICTURES = "SELECT * FROM " + TABLE_NAME;

    private final String QUERY_BY_USERNAME = "SELECT * FROM " + TABLE_NAME + " WHERE Username = ?";

    private final String QUERY_ENTRIES_COUNT = "SELECT count(*) FROM " + TABLE_NAME;

    private final String DELETE_PICTURE = "DELETE FROM " + TABLE_NAME + " WHERE PictureName = ?";

    private final String INSERT = "INSERT INTO " + TABLE_NAME + " VALUES(?,?,?,?,?,?,?,?)";

    private PreparedStatement insertInTable;
    private PreparedStatement queryByUsername;
    private PreparedStatement deletePicture;
    private PreparedStatement queryPictureByUsername;



    public Image getPicture(String username) throws IOException {
        Image userImage = null;
        try{
            queryPictureByUsername.setString(1, username);
            ResultSet picture = queryByUsername.executeQuery();
            Blob blob = picture.getBlob(1);
            InputStream inputStream = blob.getBinaryStream();
            userImage = ImageIO.read(inputStream);

        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return userImage;
    }

    public void insertPicture(File pictureFile, String pictureName, String pictureLocation, String pictureDate, String pictureHour, String pictureFormat, String username, String userType) throws IOException{
        try{

            FileInputStream fis = new FileInputStream(pictureFile);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            byte[] buf = new byte[1024];
            int bytesRead;

            while ((bytesRead = fis.read(buf)) != -1) {
                bos.write(buf, 0, bytesRead);
            }

            connection.setAutoCommit(false);
            insertInTable.setBlob(1, (Blob) pictureFile);
            insertInTable.setString(2, pictureName);
            insertInTable.setString(3, pictureLocation);
            insertInTable.setString(4, pictureDate);
            insertInTable.setString(5, pictureHour);
            insertInTable.setString(6, pictureFormat);
            insertInTable.setString(7, username);
            insertInTable.setString(8, userType);

            int rowsAffected = insertInTable.executeUpdate();

            if(rowsAffected == 1){
                connection.commit();
            }
            else{
                throw new SQLException("Error inserting in table");
            }

        }
        catch (SQLException e){
            try {
                connection.rollback();
            }
            catch (SQLException e2){

            }
            System.out.println(e.getMessage());
        }
        finally {
            try{
                connection.setAutoCommit(true);
            }
            catch (SQLException e){
                System.out.println(e.getMessage());
            }
        }
    }

    public void createTable(){
        try(Statement statement = connection.createStatement()){
            System.out.println(CREATE_TABLE + TABLE_COLUMNS);
            statement.execute(CREATE_TABLE + TABLE_COLUMNS);
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    public void openPicturesDatabase(){
        try{
            connection = DriverManager.getConnection(databaseLocation);
            queryByUsername = connection.prepareStatement(QUERY_BY_USERNAME);
            deletePicture = connection.prepareStatement(DELETE_PICTURE);
            insertInTable = connection.prepareStatement(INSERT);
            queryPictureByUsername = connection.prepareStatement(QUERY_PICTURE_BY_USERNAME);
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }


    public void closeConnection(){
        try{
            if(queryByUsername != null){
                queryByUsername.close();
            }
            if(deletePicture != null) {
                deletePicture.close();
            }
            if(insertInTable != null){
                insertInTable.close();
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }



}
