package com.example.hackathon;

public class Main {
    public static void main(String[] args) {
        MyGreenCityMain.main(args);
    }
}
