package com.example.hackathon;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginPageController {

    @FXML
    public AnchorPane loginBackground;

    @FXML
    public TextField usernameText;

    @FXML
    public TextField passwordText;

    @FXML
    public CheckBox rememberMeCheckBox;

    private Label emptyUsername = new Label("Camp gol");
    private Label emptyPassword = new Label("Camp gol");

    @FXML
    public Button loginButton;

    @FXML
    public Button registerButton;


    public void initialize() {


    }

    public void loginButtonMouseClicked() throws IOException{
        if(usernameText.getText().length() > 0 && passwordText.getText().length() > 0 &&
           !usernameText.getText().isBlank() && !passwordText.getText().isBlank()){
            loginBackground.getChildren().remove(emptyUsername);
            loginBackground.getChildren().remove(emptyPassword);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainAppPage.fxml"));
            Screen screen = Screen.getPrimary();
            Rectangle2D screenBounds = screen.getVisualBounds();
            Scene scene = new Scene(loader.load(),screenBounds.getWidth(),screenBounds.getHeight() - 30);
            Stage stage = new MyGreenCityMain().getAppStage();
            stage.setScene(scene);
            stage.centerOnScreen();
            stage.show();
        }
        else{
            userNameOrPasswordEmptyMessage();
        }
    }


    private void userNameOrPasswordEmptyMessage(){
        if(usernameText.getText().length() == 0 || usernameText.getText().isBlank()){
            emptyUsername.setFont(Font.font(10));
            emptyUsername.setTextFill(Color.RED);
            emptyUsername.setLayoutX(96);
            emptyUsername.setLayoutY(93);
            if(!loginBackground.getChildren().contains(emptyUsername)){
                loginBackground.getChildren().add(emptyUsername);
            }
        }
        if(usernameText.getText().length() > 0 && !usernameText.getText().isBlank()){
            loginBackground.getChildren().remove(emptyUsername);
        }
        if(passwordText.getText().length() == 0 || usernameText.getText().isBlank()){
            emptyPassword.setFont(Font.font(10));
            emptyPassword.setTextFill(Color.RED);
            emptyPassword.setLayoutX(96);
            emptyPassword.setLayoutY(137);
            if(!loginBackground.getChildren().contains(emptyPassword)){
                loginBackground.getChildren().add(emptyPassword);
            }
        }
        if(passwordText.getText().length() > 0 && !passwordText.getText().isBlank()){
            loginBackground.getChildren().remove(emptyPassword);
        }
    }


    public void registerButtonMouseClicked() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("RegisterPage.fxml"));
        Scene scene = new Scene(loader.load(),380,400);
        Stage stage = new MyGreenCityMain().getAppStage();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }


}